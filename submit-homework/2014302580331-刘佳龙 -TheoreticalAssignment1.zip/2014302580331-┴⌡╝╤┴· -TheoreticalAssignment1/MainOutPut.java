import jxl.read.biff.BiffException;
import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WriteException;
import java.text.DecimalFormat;
import java.io.*;
public class MainOutPut {

	public void processScoreTable(File input){
		try {
			
			//��ʼ�ɼ���
			FileInputStream in = new FileInputStream(input);
			Workbook workbook = Workbook.getWorkbook(in);
			Sheet st = workbook.getSheet(0);
			
			//������
			int R = st.getRows();
			int C = st.getColumns();
			
			//��Ȩ����
			double A = 0.0;
			
			//�ɼ�*ѧ�֣��Լ��ֿƼ���
			double a = 0.0;
			double total = 0.0;
			
			//ʹ��string����洢�ɼ�
			String arr[][] = new String [R-1][10];
			for(int i=0;i<R-1;i++){
				for(int j=0;j<10;j++){
					arr[i][j] = st.getCell(j,i).getContents().trim();
				}
			}
			//ð������
			for(int x=0;x<R-2;x++){
				String s = new String();
					for(int y=x+1;y<R-1;y++)
					{
						if(Double.valueOf(arr[y][9])>Double.valueOf(arr[x][9]))
						{
							for(int i=0;i<10;i++)
							{
								s = arr[x][i];
								arr[x][i] = arr[y][i];
								arr[y][i] = s;
							}
						}
					}
				}
				
			//����excel
				String name = "NewBook.xls";
				File file = new File(name);
				jxl.write.WritableWorkbook wk = Workbook.createWorkbook(file);
				WritableSheet wsheet = wk.createSheet("NewBook", 0);
				Label lb;
				
				//��ͷ
			 	for(int j=0;j<C-1;j++){
					lb = new Label(j,0,st.getCell(j, 0).getContents());
					wsheet.addCell(lb);
				}
				
				//ʹ�óɼ���
				for(int i =0;i<arr.length;i++){
					for(int j=0;j<10;j++){
						lb = new Label(j,i+1,arr[i][j]);
						wsheet.addCell(lb);
					}
				}
				
				//��ѧ��
				double sumscore=0.0;
				for(int i=1;i<R;i++){
					String str = st.getCell(3,i).getContents();
					double d = Double.parseDouble(str);
					sumscore = sumscore + d;
					}
				
				//��Ȩƽ���ֺͼ���
				double sum = 0.0;
				for(int i=1;i<R;i++){
					String str1 = st.getCell(9,i).getContents();
					String str2 = st.getCell(3,i).getContents();
					//���Ƴɼ�
					double d1 = Double.parseDouble(str1);
					//��Ӧѧ��
					double d2 = Double.parseDouble(str2);
					
					sum = sum + d1*d2;//����ɼ�*ѧ��֮��
					//�г���Ӧ����
					if(d1>=90 && d1<=100)a = 4.0;
					if(d1>=85 && d1<=89)a = 3.7;
					if(d1>=82 && d1<=84)a = 3.3;
					if(d1>=78 && d1<=81)a = 3.0;
					if(d1>=75 && d1<=77)a = 2.7;
					if(d1>=72 && d1<=74)a = 2.3;
					if(d1>=68 && d1<=71)a = 2.0;
					if(d1>=64 && d1<=67)a = 1.5;
					if(d1>=60 && d1<=63)a = 1.0;
					if(d1<60)a = 0.0;	
					total = total + a*d2;
				}
				
				//��Ȩƽ����
				double average = 0.0;
				DecimalFormat df=(DecimalFormat) DecimalFormat.getInstance();
				df.applyPattern("0.00");
				average = sum/sumscore;
				A = total/sumscore;
				
				//���ӵ��´�����excel����
				lb = new Label(C-1,0,"��Ȩƽ����");
				wsheet.addCell(lb);
				lb = new Label(C-1,1,df.format(average));
				wsheet.addCell(lb);
				lb = new Label(C,0,"A");
				wsheet.addCell(lb);
				lb = new Label(C,1,df.format(A));
				wsheet.addCell(lb);
				
				//����
				wk.write();
				wk.close();
				workbook.close();
				
		} 
		
		catch (BiffException e) 
		{
			e.printStackTrace();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		} 
		catch (WriteException e) 
		{
			e.printStackTrace();
		}
	
	}

	public static void main(String[] args) 
	{
		MainOutPut result = new MainOutPut();
		result.processScoreTable(new File("GradeBook.xls"));
	}
}


